-- Seed data for testing
-- This creates a sample organizational hierarchy and some test content

-- Insert sample provinces
INSERT INTO provinces (name, description) VALUES
  ('Leinster', 'Scouting Ireland - Leinster Province'),
  ('Munster', 'Scouting Ireland - Munster Province'),
  ('Connacht', 'Scouting Ireland - Connacht Province'),
  ('Ulster', 'Scouting Ireland - Ulster Province');

-- Get province IDs for reference
DO $$
DECLARE
  leinster_id UUID;
  munster_id UUID;
BEGIN
  SELECT id INTO leinster_id FROM provinces WHERE name = 'Leinster';
  SELECT id INTO munster_id FROM provinces WHERE name = 'Munster';

  -- Insert sample counties
  INSERT INTO counties (province_id, name, description) VALUES
    (leinster_id, 'Dublin', 'Dublin County'),
    (leinster_id, 'Wicklow', 'Wicklow County'),
    (munster_id, 'Cork', 'Cork County'),
    (munster_id, 'Kerry', 'Kerry County');
END $$;

-- Note: Additional groups and sections can be added through the admin interface
