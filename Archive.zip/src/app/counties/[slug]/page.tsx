import { notFound } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getCountyBySlug, getGroups } from "@/lib/supabase/queries"

export default async function CountyPage({
    params,
}: {
    params: Promise<{ slug: string }>
}) {
    const { slug } = await params
    const county = await getCountyBySlug(slug)

    if (!county) {
        notFound()
    }

    const groups = await getGroups(county.id)

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold mb-4">{county.name}</h1>
                    {county.description && (
                        <p className="text-lg text-muted-foreground">{county.description}</p>
                    )}
                </div>

                {/* Contact Info */}
                {(county.email || county.website || county.facebook_url || county.instagram_url) && (
                    <Card className="mb-8">
                        <CardHeader>
                            <CardTitle>Contact Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {county.email && (
                                <p><strong>Email:</strong> <a href={`mailto:${county.email}`} className="text-primary hover:underline">{county.email}</a></p>
                            )}
                            {county.website && (
                                <p><strong>Website:</strong> <a href={county.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{county.website}</a></p>
                            )}
                            {county.facebook_url && (
                                <p><strong>Facebook:</strong> <a href={county.facebook_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Visit Page</a></p>
                            )}
                            {county.instagram_url && (
                                <p><strong>Instagram:</strong> <a href={county.instagram_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Visit Profile</a></p>
                            )}
                        </CardContent>
                    </Card>
                )}

                {/* Tabs for Info, News, Events */}
                <Tabs defaultValue="info" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="info">Info</TabsTrigger>
                        <TabsTrigger value="news">News</TabsTrigger>
                        <TabsTrigger value="events">Events</TabsTrigger>
                    </TabsList>

                    <TabsContent value="info" className="mt-6">
                        <div>
                            <h2 className="text-2xl font-bold mb-4">Groups in {county.name}</h2>
                            {groups.length === 0 ? (
                                <Card>
                                    <CardContent className="py-12 text-center">
                                        <p className="text-muted-foreground">No groups found in this county.</p>
                                    </CardContent>
                                </Card>
                            ) : (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {groups.map((group) => (
                                        <Link key={group.id} href={`/groups/${group.slug}`}>
                                            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                                                <CardHeader>
                                                    <CardTitle>{group.name}</CardTitle>
                                                    {group.description && (
                                                        <CardDescription className="line-clamp-2">
                                                            {group.description}
                                                        </CardDescription>
                                                    )}
                                                </CardHeader>
                                            </Card>
                                        </Link>
                                    ))}
                                </div>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="news" className="mt-6">
                        <Card>
                            <CardContent className="py-12 text-center">
                                <p className="text-muted-foreground">News posts coming soon...</p>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="events" className="mt-6">
                        <Card>
                            <CardContent className="py-12 text-center">
                                <p className="text-muted-foreground">Events coming soon...</p>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    )
}
