import { notFound } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getGroupBySlug, getSections } from "@/lib/supabase/queries"

export default async function GroupPage({
    params,
}: {
    params: Promise<{ slug: string }>
}) {
    const { slug } = await params
    const group = await getGroupBySlug(slug)

    if (!group) {
        notFound()
    }

    const sections = await getSections(group.id)

    // Format section type for display
    const formatSectionType = (type: string) => {
        return type.charAt(0).toUpperCase() + type.slice(1)
    }

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold mb-4">{group.name}</h1>
                    {group.description && (
                        <p className="text-lg text-muted-foreground">{group.description}</p>
                    )}
                </div>

                {/* Contact Info */}
                {(group.email || group.website || group.facebook_url || group.instagram_url) && (
                    <Card className="mb-8">
                        <CardHeader>
                            <CardTitle>Contact Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {group.email && (
                                <p><strong>Email:</strong> <a href={`mailto:${group.email}`} className="text-primary hover:underline">{group.email}</a></p>
                            )}
                            {group.website && (
                                <p><strong>Website:</strong> <a href={group.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{group.website}</a></p>
                            )}
                            {group.facebook_url && (
                                <p><strong>Facebook:</strong> <a href={group.facebook_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Visit Page</a></p>
                            )}
                            {group.instagram_url && (
                                <p><strong>Instagram:</strong> <a href={group.instagram_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Visit Profile</a></p>
                            )}
                        </CardContent>
                    </Card>
                )}

                {/* Tabs for Info, News, Events */}
                <Tabs defaultValue="info" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="info">Info</TabsTrigger>
                        <TabsTrigger value="news">News</TabsTrigger>
                        <TabsTrigger value="events">Events</TabsTrigger>
                    </TabsList>

                    <TabsContent value="info" className="mt-6">
                        <div>
                            <h2 className="text-2xl font-bold mb-4">Sections in {group.name}</h2>
                            {sections.length === 0 ? (
                                <Card>
                                    <CardContent className="py-12 text-center">
                                        <p className="text-muted-foreground">No sections found in this group.</p>
                                    </CardContent>
                                </Card>
                            ) : (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {sections.map((section) => (
                                        <Card key={section.id}>
                                            <CardHeader>
                                                <CardTitle>{section.name}</CardTitle>
                                                <CardDescription>
                                                    {formatSectionType(section.section_type)}
                                                </CardDescription>
                                            </CardHeader>
                                            {section.description && (
                                                <CardContent>
                                                    <p className="text-sm text-muted-foreground">{section.description}</p>
                                                </CardContent>
                                            )}
                                        </Card>
                                    ))}
                                </div>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="news" className="mt-6">
                        <Card>
                            <CardContent className="py-12 text-center">
                                <p className="text-muted-foreground">News posts coming soon...</p>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="events" className="mt-6">
                        <Card>
                            <CardContent className="py-12 text-center">
                                <p className="text-muted-foreground">Events coming soon...</p>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    )
}
