import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getGroups } from "@/lib/supabase/queries"

export default async function GroupsPage() {
    const groups = await getGroups()

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
                <h1 className="text-4xl font-bold mb-4">Groups</h1>
                <p className="text-lg text-muted-foreground mb-12">
                    Connect with local scouting groups
                </p>

                {groups.length === 0 ? (
                    <Card>
                        <CardContent className="py-12 text-center">
                            <p className="text-muted-foreground">
                                No groups found. Please add groups via the admin dashboard.
                            </p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {groups.map((group) => (
                            <Link key={group.id} href={`/groups/${group.slug}`}>
                                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                                    <CardHeader>
                                        <CardTitle>{group.name}</CardTitle>
                                        {group.description && (
                                            <CardDescription className="line-clamp-2">
                                                {group.description}
                                            </CardDescription>
                                        )}
                                    </CardHeader>
                                    {(group.email || group.website) && (
                                        <CardContent>
                                            <div className="text-sm text-muted-foreground space-y-1">
                                                {group.email && <p>Email: {group.email}</p>}
                                                {group.website && <p>Website: {group.website}</p>}
                                            </div>
                                        </CardContent>
                                    )}
                                </Card>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}
