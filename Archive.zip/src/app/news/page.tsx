import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getNewsPosts, getProvinces, getCounties, getGroups } from "@/lib/supabase/queries"
import { Calendar, Tag } from "lucide-react"

interface NewsPageProps {
    searchParams: Promise<{
        search?: string
        provinceId?: string
        countyId?: string
        groupId?: string
        tag?: string
    }>
}

export default async function NewsPage({ searchParams }: NewsPageProps) {
    const params = await searchParams
    
    const filters = {
        search: params.search,
        provinceId: params.provinceId,
        countyId: params.countyId,
        groupId: params.groupId,
        tag: params.tag,
    }

    const newsPosts = await getNewsPosts(filters)
    const provinces = await getProvinces()
    const counties = params.provinceId ? await getCounties(params.provinceId) : []
    const groups = params.countyId ? await getGroups(params.countyId) : []

    // Extract all unique tags from news posts
    const allTags = Array.from(
        new Set(newsPosts.flatMap(post => post.tags || []))
    ).sort()

    const formatDate = (dateString: string | null) => {
        if (!dateString) return 'Not published'
        const date = new Date(dateString)
        return date.toLocaleDateString('en-IE', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        })
    }

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-6xl mx-auto">
                <h1 className="text-4xl font-bold mb-4">News</h1>
                <p className="text-lg text-muted-foreground mb-8">
                    Stay updated with the latest scouting news across Ireland
                </p>

                {/* Filters */}
                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Filters</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form method="get" className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Search</label>
                                    <input
                                        type="text"
                                        name="search"
                                        placeholder="Search news..."
                                        defaultValue={params.search}
                                        className="w-full px-3 py-2 border rounded-md"
                                    />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Tag</label>
                                    <select
                                        name="tag"
                                        defaultValue={params.tag}
                                        className="w-full px-3 py-2 border rounded-md"
                                    >
                                        <option value="">All Tags</option>
                                        {allTags.map((tag) => (
                                            <option key={tag} value={tag}>
                                                {tag}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Province</label>
                                    <select
                                        name="provinceId"
                                        defaultValue={params.provinceId}
                                        className="w-full px-3 py-2 border rounded-md"
                                    >
                                        <option value="">All Provinces</option>
                                        {provinces.map((province) => (
                                            <option key={province.id} value={province.id}>
                                                {province.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                {params.provinceId && (
                                    <div>
                                        <label className="text-sm font-medium mb-2 block">County</label>
                                        <select
                                            name="countyId"
                                            defaultValue={params.countyId}
                                            className="w-full px-3 py-2 border rounded-md"
                                        >
                                            <option value="">All Counties</option>
                                            {counties.map((county) => (
                                                <option key={county.id} value={county.id}>
                                                    {county.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                                {params.countyId && (
                                    <div>
                                        <label className="text-sm font-medium mb-2 block">Group</label>
                                        <select
                                            name="groupId"
                                            defaultValue={params.groupId}
                                            className="w-full px-3 py-2 border rounded-md"
                                        >
                                            <option value="">All Groups</option>
                                            {groups.map((group) => (
                                                <option key={group.id} value={group.id}>
                                                    {group.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                            </div>
                            <div className="flex gap-2">
                                <Button type="submit">Apply Filters</Button>
                                <Button type="button" variant="outline" asChild>
                                    <Link href="/news">Clear</Link>
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>

                {/* News List */}
                {newsPosts.length === 0 ? (
                    <Card>
                        <CardContent className="py-12 text-center">
                            <p className="text-muted-foreground">
                                No news posts found. Try adjusting your filters.
                            </p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {newsPosts.map((post) => (
                            <Link key={post.id} href={`/news/${post.slug}`}>
                                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer flex flex-col">
                                    {post.featured_image_url && (
                                        <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted">
                                            <img
                                                src={post.featured_image_url}
                                                alt={post.title}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>
                                    )}
                                    <CardHeader className="flex-1">
                                        <CardTitle className="line-clamp-2">{post.title}</CardTitle>
                                        <CardDescription className="flex items-center gap-2 mt-2">
                                            <Calendar className="h-4 w-4" />
                                            {formatDate(post.published_at)}
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent className="flex-1 flex flex-col">
                                        {post.body && (
                                            <p className="text-sm text-muted-foreground line-clamp-3 mb-3 flex-1">
                                                {post.body.replace(/<[^>]*>/g, '').substring(0, 150)}
                                            </p>
                                        )}
                                        {post.tags && post.tags.length > 0 && (
                                            <div className="flex flex-wrap gap-2">
                                                {post.tags.slice(0, 3).map((tag) => (
                                                    <span
                                                        key={tag}
                                                        className="text-xs px-2 py-1 bg-muted rounded-full flex items-center gap-1"
                                                    >
                                                        <Tag className="h-3 w-3" />
                                                        {tag}
                                                    </span>
                                                ))}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}

