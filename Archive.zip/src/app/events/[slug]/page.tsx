import { notFound } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getEventBySlug } from "@/lib/supabase/queries"
import { Calendar, MapPin, Tag, Users, Euro } from "lucide-react"
import Link from "next/link"

export default async function EventPage({
    params,
}: {
    params: Promise<{ slug: string }>
}) {
    const { slug } = await params
    const event = await getEventBySlug(slug)

    if (!event) {
        notFound()
    }

    const formatDate = (dateString: string) => {
        const date = new Date(dateString)
        return date.toLocaleDateString('en-IE', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        })
    }

    const formatTime = (dateString: string) => {
        const date = new Date(dateString)
        return date.toLocaleTimeString('en-IE', {
            hour: '2-digit',
            minute: '2-digit',
        })
    }

    const formatDateTime = (dateString: string) => {
        return `${formatDate(dateString)} at ${formatTime(dateString)}`
    }

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
                <div className="mb-6">
                    <Button variant="ghost" asChild>
                        <Link href="/events">← Back to Events</Link>
                    </Button>
                </div>

                {event.featured_image_url && (
                    <div className="aspect-video w-full overflow-hidden rounded-lg bg-muted mb-8">
                        <img
                            src={event.featured_image_url}
                            alt={event.title}
                            className="w-full h-full object-cover"
                        />
                    </div>
                )}

                <h1 className="text-4xl font-bold mb-4">{event.title}</h1>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Calendar className="h-5 w-5" />
                                Date & Time
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="font-medium">{formatDateTime(event.start_date)}</p>
                            {event.end_date && (
                                <p className="text-sm text-muted-foreground mt-1">
                                    Ends: {formatDateTime(event.end_date)}
                                </p>
                            )}
                        </CardContent>
                    </Card>

                    {event.location && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <MapPin className="h-5 w-5" />
                                    Location
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p>{event.location}</p>
                            </CardContent>
                        </Card>
                    )}

                    {(event.price || event.price_scouter || event.price_youth) && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Euro className="h-5 w-5" />
                                    Pricing
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                {event.pricing_mode === 'per_person_type' ? (
                                    <div className="space-y-1">
                                        {event.price_scouter !== null && (
                                            <p>Scouters: €{event.price_scouter.toFixed(2)}</p>
                                        )}
                                        {event.price_youth !== null && (
                                            <p>Youth: €{event.price_youth.toFixed(2)}</p>
                                        )}
                                    </div>
                                ) : event.price ? (
                                    <p>€{event.price.toFixed(2)}</p>
                                ) : (
                                    <p>Free</p>
                                )}
                            </CardContent>
                        </Card>
                    )}

                    {(event.capacity_groups || event.capacity_scouters || event.capacity_youth) && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Users className="h-5 w-5" />
                                    Capacity
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-1">
                                    {event.capacity_groups !== null && (
                                        <p>Groups: {event.capacity_groups}</p>
                                    )}
                                    {event.capacity_scouters !== null && (
                                        <p>Scouters: {event.capacity_scouters}</p>
                                    )}
                                    {event.capacity_youth !== null && (
                                        <p>Youth: {event.capacity_youth}</p>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </div>

                {event.body && (
                    <Card className="mb-8">
                        <CardHeader>
                            <CardTitle>Description</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div
                                className="prose max-w-none"
                                dangerouslySetInnerHTML={{ __html: event.body }}
                            />
                        </CardContent>
                    </Card>
                )}

                {event.tags && event.tags.length > 0 && (
                    <Card className="mb-8">
                        <CardHeader>
                            <CardTitle>Tags</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex flex-wrap gap-2">
                                {event.tags.map((tag) => (
                                    <span
                                        key={tag}
                                        className="text-sm px-3 py-1 bg-muted rounded-full flex items-center gap-1"
                                    >
                                        <Tag className="h-3 w-3" />
                                        {tag}
                                    </span>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                )}

                <Card>
                    <CardHeader>
                        <CardTitle>Event Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                        <p><strong>Visibility:</strong> {event.visibility.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
                        <p><strong>Registration Required:</strong> {event.require_participant_info ? 'Yes' : 'No'}</p>
                        <p><strong>Payment Required:</strong> {event.require_payment ? 'Yes' : 'No'}</p>
                    </CardContent>
                </Card>

                <div className="mt-8">
                    <Button size="lg" className="w-full md:w-auto">
                        Register for Event
                    </Button>
                </div>
            </div>
        </div>
    )
}

