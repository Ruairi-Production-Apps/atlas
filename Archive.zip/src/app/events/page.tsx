import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getEvents, getProvinces, getCounties, getGroups } from "@/lib/supabase/queries"
import { Calendar, MapPin, Tag } from "lucide-react"

interface EventsPageProps {
    searchParams: Promise<{
        search?: string
        dateFrom?: string
        dateTo?: string
        provinceId?: string
        countyId?: string
        groupId?: string
        visibility?: string
    }>
}

export default async function EventsPage({ searchParams }: EventsPageProps) {
    const params = await searchParams
    
    const filters = {
        search: params.search,
        dateFrom: params.dateFrom,
        dateTo: params.dateTo,
        provinceId: params.provinceId,
        countyId: params.countyId,
        groupId: params.groupId,
        visibility: params.visibility as 'open_to_all' | 'sections_only' | 'scouters_only' | undefined,
    }

    const events = await getEvents(filters)
    const provinces = await getProvinces()
    const counties = params.provinceId ? await getCounties(params.provinceId) : []
    const groups = params.countyId ? await getGroups(params.countyId) : []

    const formatDate = (dateString: string) => {
        const date = new Date(dateString)
        return date.toLocaleDateString('en-IE', {
            weekday: 'short',
            year: 'numeric',
            month: 'short',
            day: 'numeric',
        })
    }

    const formatTime = (dateString: string) => {
        const date = new Date(dateString)
        return date.toLocaleTimeString('en-IE', {
            hour: '2-digit',
            minute: '2-digit',
        })
    }

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-6xl mx-auto">
                <h1 className="text-4xl font-bold mb-4">Events</h1>
                <p className="text-lg text-muted-foreground mb-8">
                    Discover upcoming scouting events across Ireland
                </p>

                {/* Filters */}
                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Filters</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form method="get" className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Search</label>
                                    <input
                                        type="text"
                                        name="search"
                                        placeholder="Search events..."
                                        defaultValue={params.search}
                                        className="w-full px-3 py-2 border rounded-md"
                                    />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-2 block">From Date</label>
                                    <input
                                        type="date"
                                        name="dateFrom"
                                        defaultValue={params.dateFrom}
                                        className="w-full px-3 py-2 border rounded-md"
                                    />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-2 block">To Date</label>
                                    <input
                                        type="date"
                                        name="dateTo"
                                        defaultValue={params.dateTo}
                                        className="w-full px-3 py-2 border rounded-md"
                                    />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Visibility</label>
                                    <select
                                        name="visibility"
                                        defaultValue={params.visibility}
                                        className="w-full px-3 py-2 border rounded-md"
                                    >
                                        <option value="">All</option>
                                        <option value="open_to_all">Open to All</option>
                                        <option value="sections_only">Sections Only</option>
                                        <option value="scouters_only">Scouters Only</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Province</label>
                                    <select
                                        name="provinceId"
                                        defaultValue={params.provinceId}
                                        className="w-full px-3 py-2 border rounded-md"
                                    >
                                        <option value="">All Provinces</option>
                                        {provinces.map((province) => (
                                            <option key={province.id} value={province.id}>
                                                {province.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                {params.provinceId && (
                                    <div>
                                        <label className="text-sm font-medium mb-2 block">County</label>
                                        <select
                                            name="countyId"
                                            defaultValue={params.countyId}
                                            className="w-full px-3 py-2 border rounded-md"
                                        >
                                            <option value="">All Counties</option>
                                            {counties.map((county) => (
                                                <option key={county.id} value={county.id}>
                                                    {county.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                                {params.countyId && (
                                    <div>
                                        <label className="text-sm font-medium mb-2 block">Group</label>
                                        <select
                                            name="groupId"
                                            defaultValue={params.groupId}
                                            className="w-full px-3 py-2 border rounded-md"
                                        >
                                            <option value="">All Groups</option>
                                            {groups.map((group) => (
                                                <option key={group.id} value={group.id}>
                                                    {group.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                            </div>
                            <div className="flex gap-2">
                                <Button type="submit">Apply Filters</Button>
                                <Button type="button" variant="outline" asChild>
                                    <Link href="/events">Clear</Link>
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>

                {/* Events List */}
                {events.length === 0 ? (
                    <Card>
                        <CardContent className="py-12 text-center">
                            <p className="text-muted-foreground">
                                No events found. Try adjusting your filters.
                            </p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {events.map((event) => (
                            <Link key={event.id} href={`/events/${event.slug}`}>
                                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                                    {event.featured_image_url && (
                                        <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted">
                                            <img
                                                src={event.featured_image_url}
                                                alt={event.title}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>
                                    )}
                                    <CardHeader>
                                        <CardTitle className="line-clamp-2">{event.title}</CardTitle>
                                        <CardDescription className="flex items-center gap-4 mt-2">
                                            <span className="flex items-center gap-1">
                                                <Calendar className="h-4 w-4" />
                                                {formatDate(event.start_date)}
                                            </span>
                                            {event.location && (
                                                <span className="flex items-center gap-1">
                                                    <MapPin className="h-4 w-4" />
                                                    {event.location}
                                                </span>
                                            )}
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        {event.body && (
                                            <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
                                                {event.body.replace(/<[^>]*>/g, '').substring(0, 150)}
                                            </p>
                                        )}
                                        {event.tags && event.tags.length > 0 && (
                                            <div className="flex flex-wrap gap-2">
                                                {event.tags.slice(0, 3).map((tag) => (
                                                    <span
                                                        key={tag}
                                                        className="text-xs px-2 py-1 bg-muted rounded-full flex items-center gap-1"
                                                    >
                                                        <Tag className="h-3 w-3" />
                                                        {tag}
                                                    </span>
                                                ))}
                                            </div>
                                        )}
                                        {event.price && (
                                            <p className="text-sm font-medium mt-2">
                                                €{event.price.toFixed(2)}
                                            </p>
                                        )}
                                    </CardContent>
                                </Card>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}

