import { notFound } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getProvinceBySlug, getCounties } from "@/lib/supabase/queries"

export default async function ProvincePage({
    params,
}: {
    params: Promise<{ slug: string }>
}) {
    const { slug } = await params
    const province = await getProvinceBySlug(slug)

    if (!province) {
        notFound()
    }

    const counties = await getCounties(province.id)

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold mb-4">{province.name}</h1>
                    {province.description && (
                        <p className="text-lg text-muted-foreground">{province.description}</p>
                    )}
                </div>

                {/* Contact Info */}
                {(province.email || province.website || province.facebook_url || province.instagram_url) && (
                    <Card className="mb-8">
                        <CardHeader>
                            <CardTitle>Contact Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {province.email && (
                                <p><strong>Email:</strong> <a href={`mailto:${province.email}`} className="text-primary hover:underline">{province.email}</a></p>
                            )}
                            {province.website && (
                                <p><strong>Website:</strong> <a href={province.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{province.website}</a></p>
                            )}
                            {province.facebook_url && (
                                <p><strong>Facebook:</strong> <a href={province.facebook_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Visit Page</a></p>
                            )}
                            {province.instagram_url && (
                                <p><strong>Instagram:</strong> <a href={province.instagram_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Visit Profile</a></p>
                            )}
                        </CardContent>
                    </Card>
                )}

                {/* Tabs for Info, News, Events */}
                <Tabs defaultValue="info" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="info">Info</TabsTrigger>
                        <TabsTrigger value="news">News</TabsTrigger>
                        <TabsTrigger value="events">Events</TabsTrigger>
                    </TabsList>

                    <TabsContent value="info" className="mt-6">
                        <div>
                            <h2 className="text-2xl font-bold mb-4">Counties in {province.name}</h2>
                            {counties.length === 0 ? (
                                <Card>
                                    <CardContent className="py-12 text-center">
                                        <p className="text-muted-foreground">No counties found in this province.</p>
                                    </CardContent>
                                </Card>
                            ) : (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {counties.map((county) => (
                                        <Link key={county.id} href={`/counties/${county.slug}`}>
                                            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                                                <CardHeader>
                                                    <CardTitle>{county.name}</CardTitle>
                                                    {county.description && (
                                                        <CardDescription className="line-clamp-2">
                                                            {county.description}
                                                        </CardDescription>
                                                    )}
                                                </CardHeader>
                                            </Card>
                                        </Link>
                                    ))}
                                </div>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="news" className="mt-6">
                        <Card>
                            <CardContent className="py-12 text-center">
                                <p className="text-muted-foreground">News posts coming soon...</p>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="events" className="mt-6">
                        <Card>
                            <CardContent className="py-12 text-center">
                                <p className="text-muted-foreground">Events coming soon...</p>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    )
}
