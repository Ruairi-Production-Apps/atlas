import { createClient } from '@/lib/supabase/server'

export interface Province {
    id: string
    name: string
    slug: string
    description: string | null
    logo_url: string | null
    website: string | null
    email: string | null
    facebook_url: string | null
    instagram_url: string | null
    created_at: string
    updated_at: string
}

export interface County extends Province {
    province_id: string
}

export interface Group extends County {
    county_id: string
}

export interface Section {
    id: string
    group_id: string
    name: string
    section_type: 'beavers' | 'cubs' | 'scouts' | 'ventures' | 'rovers'
    description: string | null
    created_at: string
    updated_at: string
}

// Province queries
export async function getProvinces(): Promise<Province[]> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('provinces')
        .select('*')
        .order('name')

    if (error) throw error
    return data || []
}

export async function getProvinceBySlug(slug: string): Promise<Province | null> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('provinces')
        .select('*')
        .eq('slug', slug)
        .single()

    if (error) return null
    return data
}

// County queries
export async function getCounties(provinceId?: string): Promise<County[]> {
    const supabase = await createClient()
    let query = supabase
        .from('counties')
        .select('*')
        .order('name')

    if (provinceId) {
        query = query.eq('province_id', provinceId)
    }

    const { data, error } = await query

    if (error) throw error
    return data || []
}

export async function getCountyBySlug(slug: string): Promise<County | null> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('counties')
        .select('*')
        .eq('slug', slug)
        .single()

    if (error) return null
    return data
}

// Group queries
export async function getGroups(countyId?: string): Promise<Group[]> {
    const supabase = await createClient()
    let query = supabase
        .from('groups')
        .select('*')
        .order('name')

    if (countyId) {
        query = query.eq('county_id', countyId)
    }

    const { data, error } = await query

    if (error) throw error
    return data || []
}

export async function getGroupBySlug(slug: string): Promise<Group | null> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('groups')
        .select('*')
        .eq('slug', slug)
        .single()

    if (error) return null
    return data
}

// Section queries
export async function getSections(groupId: string): Promise<Section[]> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('sections')
        .select('*')
        .eq('group_id', groupId)
        .order('section_type')

    if (error) throw error
    return data || []
}

// Event interfaces
export interface Event {
    id: string
    title: string
    slug: string
    featured_image_url: string | null
    body: string | null
    tags: string[]
    start_date: string
    end_date: string | null
    location: string | null
    price: number | null
    capacity_groups: number | null
    capacity_scouters: number | null
    capacity_youth: number | null
    scope_type: 'province' | 'county' | 'group' | 'section'
    scope_id: string
    visibility: 'open_to_all' | 'sections_only' | 'scouters_only'
    pricing_mode: 'per_group' | 'per_scout' | 'per_person_type' | null
    price_scouter: number | null
    price_youth: number | null
    require_participant_info: boolean
    require_payment: boolean
    published: boolean
    published_at: string | null
    created_at: string
    updated_at: string
}

export interface EventFilters {
    dateFrom?: string
    dateTo?: string
    section?: string
    provinceId?: string
    countyId?: string
    groupId?: string
    visibility?: 'open_to_all' | 'sections_only' | 'scouters_only'
    search?: string
}

// Event queries
export async function getEvents(filters?: EventFilters): Promise<Event[]> {
    const supabase = await createClient()
    let query = supabase
        .from('events')
        .select('*')
        .eq('published', true)
        .order('start_date', { ascending: true })

    if (filters?.dateFrom) {
        query = query.gte('start_date', filters.dateFrom)
    }
    if (filters?.dateTo) {
        query = query.lte('start_date', filters.dateTo)
    }
    if (filters?.provinceId) {
        query = query.eq('scope_type', 'province').eq('scope_id', filters.provinceId)
    }
    if (filters?.countyId) {
        query = query.eq('scope_type', 'county').eq('scope_id', filters.countyId)
    }
    if (filters?.groupId) {
        query = query.eq('scope_type', 'group').eq('scope_id', filters.groupId)
    }
    if (filters?.visibility) {
        query = query.eq('visibility', filters.visibility)
    }
    if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,body.ilike.%${filters.search}%`)
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
}

export async function getEventBySlug(slug: string): Promise<Event | null> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('slug', slug)
        .eq('published', true)
        .single()

    if (error) return null
    return data
}

// Get events for a scope (province/county/group) including child scopes
export async function getEventsForScope(
    scopeType: 'province' | 'county' | 'group',
    scopeId: string
): Promise<Event[]> {
    const supabase = await createClient()
    
    // Get direct events for this scope
    let query = supabase
        .from('events')
        .select('*')
        .eq('scope_type', scopeType)
        .eq('scope_id', scopeId)
        .eq('published', true)
        .order('start_date', { ascending: true })

    const { data: directEvents, error: directError } = await query
    if (directError) throw directError

    // For provinces, also get county and group events
    if (scopeType === 'province') {
        const counties = await getCounties(scopeId)
        const countyIds = counties.map(c => c.id)
        
        if (countyIds.length > 0) {
            const { data: countyEvents, error: countyError } = await supabase
                .from('events')
                .select('*')
                .eq('scope_type', 'county')
                .in('scope_id', countyIds)
                .eq('published', true)
                .order('start_date', { ascending: true })
            
            if (countyError) throw countyError
            
            // Get groups for all counties
            const allGroups: Group[] = []
            for (const county of counties) {
                const groups = await getGroups(county.id)
                allGroups.push(...groups)
            }
            const groupIds = allGroups.map(g => g.id)
            
            if (groupIds.length > 0) {
                const { data: groupEvents, error: groupError } = await supabase
                    .from('events')
                    .select('*')
                    .eq('scope_type', 'group')
                    .in('scope_id', groupIds)
                    .eq('published', true)
                    .order('start_date', { ascending: true })
                
                if (groupError) throw groupError
                
                return [...(directEvents || []), ...(countyEvents || []), ...(groupEvents || [])]
            }
            
            return [...(directEvents || []), ...(countyEvents || [])]
        }
    }
    
    // For counties, also get group events
    if (scopeType === 'county') {
        const groups = await getGroups(scopeId)
        const groupIds = groups.map(g => g.id)
        
        if (groupIds.length > 0) {
            const { data: groupEvents, error: groupError } = await supabase
                .from('events')
                .select('*')
                .eq('scope_type', 'group')
                .in('scope_id', groupIds)
                .eq('published', true)
                .order('start_date', { ascending: true })
            
            if (groupError) throw groupError
            return [...(directEvents || []), ...(groupEvents || [])]
        }
    }

    return directEvents || []
}

// News interfaces
export interface NewsPost {
    id: string
    title: string
    slug: string
    featured_image_url: string | null
    body: string | null
    tags: string[]
    scope_type: 'province' | 'county' | 'group' | 'section'
    scope_id: string
    published: boolean
    published_at: string | null
    created_at: string
    updated_at: string
}

export interface NewsFilters {
    provinceId?: string
    countyId?: string
    groupId?: string
    tag?: string
    search?: string
}

// News queries
export async function getNewsPosts(filters?: NewsFilters): Promise<NewsPost[]> {
    const supabase = await createClient()
    let query = supabase
        .from('news_posts')
        .select('*')
        .eq('published', true)
        .order('published_at', { ascending: false })

    if (filters?.provinceId) {
        query = query.eq('scope_type', 'province').eq('scope_id', filters.provinceId)
    }
    if (filters?.countyId) {
        query = query.eq('scope_type', 'county').eq('scope_id', filters.countyId)
    }
    if (filters?.groupId) {
        query = query.eq('scope_type', 'group').eq('scope_id', filters.groupId)
    }
    if (filters?.tag) {
        query = query.contains('tags', [filters.tag])
    }
    if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,body.ilike.%${filters.search}%`)
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
}

export async function getNewsPostBySlug(slug: string): Promise<NewsPost | null> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('news_posts')
        .select('*')
        .eq('slug', slug)
        .eq('published', true)
        .single()

    if (error) return null
    return data
}

export async function getNewsPostsForScope(
    scopeType: 'province' | 'county' | 'group',
    scopeId: string
): Promise<NewsPost[]> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('news_posts')
        .select('*')
        .eq('scope_type', scopeType)
        .eq('scope_id', scopeId)
        .eq('published', true)
        .order('published_at', { ascending: false })

    if (error) throw error
    return data || []
}

// Knowledgebase interfaces
export interface KnowledgebaseArticle {
    id: string
    title: string
    slug: string
    body: string | null
    tags: string[]
    scope_type: 'province' | 'county' | 'group' | 'section'
    scope_id: string
    published: boolean
    published_at: string | null
    created_at: string
    updated_at: string
}

export interface KnowledgebaseFile {
    id: string
    article_id: string
    file_name: string
    file_url: string
    file_size: number | null
    mime_type: string | null
    created_at: string
}

export interface KnowledgebaseFilters {
    provinceId?: string
    countyId?: string
    groupId?: string
    search?: string
}

// Knowledgebase queries
export async function getKnowledgebaseArticles(filters?: KnowledgebaseFilters): Promise<KnowledgebaseArticle[]> {
    const supabase = await createClient()
    let query = supabase
        .from('knowledgebase_articles')
        .select('*')
        .eq('published', true)
        .order('published_at', { ascending: false })

    if (filters?.provinceId) {
        query = query.eq('scope_type', 'province').eq('scope_id', filters.provinceId)
    }
    if (filters?.countyId) {
        query = query.eq('scope_type', 'county').eq('scope_id', filters.countyId)
    }
    if (filters?.groupId) {
        query = query.eq('scope_type', 'group').eq('scope_id', filters.groupId)
    }
    if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,body.ilike.%${filters.search}%`)
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
}

export async function getKnowledgebaseArticleBySlug(slug: string): Promise<KnowledgebaseArticle | null> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('knowledgebase_articles')
        .select('*')
        .eq('slug', slug)
        .eq('published', true)
        .single()

    if (error) return null
    return data
}

export async function getKnowledgebaseFiles(articleId: string): Promise<KnowledgebaseFile[]> {
    const supabase = await createClient()
    const { data, error } = await supabase
        .from('knowledgebase_files')
        .select('*')
        .eq('article_id', articleId)
        .order('created_at', { ascending: true })

    if (error) throw error
    return data || []
}
