import Link from 'next/link'
import { Button } from '@/components/ui/button'

export function Header() {
    return (
        <header className="border-b">
            <div className="container mx-auto px-4 py-4">
                <div className="flex items-center justify-between">
                    <Link href="/" className="text-2xl font-bold text-primary">
                        Scout Hub
                    </Link>

                    <nav className="hidden md:flex items-center gap-6">
                        <Link href="/" className="text-sm font-medium hover:text-primary transition-colors">
                            Home
                        </Link>
                        <Link href="/provinces" className="text-sm font-medium hover:text-primary transition-colors">
                            Provinces
                        </Link>
                        <Link href="/counties" className="text-sm font-medium hover:text-primary transition-colors">
                            Counties
                        </Link>
                        <Link href="/groups" className="text-sm font-medium hover:text-primary transition-colors">
                            Groups
                        </Link>
                        <Link href="/events" className="text-sm font-medium hover:text-primary transition-colors">
                            Events
                        </Link>
                        <Link href="/news" className="text-sm font-medium hover:text-primary transition-colors">
                            News
                        </Link>
                        <Link href="/knowledgebase" className="text-sm font-medium hover:text-primary transition-colors">
                            Knowledgebase
                        </Link>
                    </nav>

                    <div className="flex items-center gap-2">
                        <Button variant="ghost" asChild>
                            <Link href="/login">Login</Link>
                        </Button>
                        <Button asChild>
                            <Link href="/signup">Sign Up</Link>
                        </Button>
                    </div>
                </div>
            </div>
        </header>
    )
}
